import { createSlice } from "@reduxjs/toolkit";
import UsersData from '../ListOfUsesr'
export const userSlice = createSlice({
    name: "users",
    initialState: {value: UsersData},
    reducers: {
        addUser: (state, action)=>{  state.value.push(action.payload);},
        deleteUser: (state, action)=>{state.value = state.value.filter((user)=> user.id !== action.payload.id);
	},
        updateUsername: (state, action)=>{ // Write code for updateUsername function
                 }
     }
});
export default userSlice.reducer;
export const {addUser, deleteUser, updateUsername} = userSlice.actions;
