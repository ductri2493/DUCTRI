import ButtonAppBar from './components/Header'
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Unstable_Grid2';
import { Button, TextField } from '@mui/material';
import Users from './components/Users';
import { useId, useState } from 'react';
import { useDispatch } from 'react-redux';
import { addUser } from './features/Users';
const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));
function App() {
  const [name, setName] = useState('');
const [username,setUsername] = useState('');
const dispatch = useDispatch()
const id = useId()
  return (
    <>
      <ButtonAppBar/>
      <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
        
        <Grid xs={4}>
          <Item>
          <TextField fullWidth label="name" value={name} onChange={(event) => {setName(event.target.value);}} />
          <TextField fullWidth label="username" value={username} onChange={(event) => {setUsername(event.target.value);}} />
          <Button variant="outlined" onClick={()=> {
              dispatch(addUser({id: id, name: name, username: username}));
              setName('')
              setUsername('')
              }}
>Add User</Button>
          </Item>
        </Grid>
        <Grid xs={8}>
          <Item>
            <Users/>
          </Item>
        </Grid>
      </Grid>
    </Box>
    </>
  )
}

export default App
