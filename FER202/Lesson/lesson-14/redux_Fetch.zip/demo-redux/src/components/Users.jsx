import * as React from 'react';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import ImageIcon from '@mui/icons-material/Image';
import { Button, Divider, TextField } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { deleteUser } from '../features/Users';

export default function Users() {
    const userList = useSelector((state)=> state.users.value);  
    const dispatch = useDispatch()
  return (
    <List sx={{ width: '100%', bgcolor: 'background.paper' }}>
        {userList.map((user)=>{
            return(
                <>
                <ListItem>
        <ListItemAvatar>
          <Avatar>
            <ImageIcon />
          </Avatar>
        </ListItemAvatar>
        <ListItemText primary={user.name} secondary={user.username} />
        <TextField fullWidth label='Type your username'/>
        <Button color='secondary'>Edit</Button>
        <Button color="error" onClick={()=> {
      dispatch(deleteUser({id: user.id}));
      }}>Delete</Button>
      </ListItem>
      <Divider/>
      </>
            )
        })}
      
      
    </List>
  );
}