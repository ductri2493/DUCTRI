import { Button, Dialog, DialogActions, DialogTitle } from '@mui/material';
import React, { useState, useEffect } from 'react'

export default function FetchAPI() {
    const url = 'https://65e0222ad3db23f7624859a6.mockapi.io/studentManagement/'
    const[api, setAPI] = useState([])
    const[open,setOpen] = useState(false)
    const handleClose = () => {
        setOpen(false);
      };
    useEffect(() => {
        fetch(url)
        .then(response => response.json())
        .then(data => setAPI(data))
        .catch(error => console.log(error.message));
    }, [open])
    
    const handleDelete = (id)=>{
        if(confirm('Are you sure?')){
            fetch(url + id, {method: 'DELETE'})
        .then(setOpen(true))
        .catch(error => console.log(error.message));
        }
        
    }
  
  return (
    <div>
        <ul>
            {api.map((a)=>(
             <><li key={a.id}>{a.name}</li> <Button onClick={()=> handleDelete(a.id)}>X</Button></>   
            ))}
        </ul>
        <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          {"Delete successful!"}
        </DialogTitle>
        
        <DialogActions>
          <Button onClick={handleClose}>Close</Button>  
        </DialogActions>
      </Dialog>
    </div>
  )
}
