import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import CloseIcon from '@mui/icons-material/Close';
import { Alert, AlertTitle, Avatar, Button, Collapse, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, IconButton, Slide } from '@mui/material';
import { useState } from 'react';
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});
export default function BasicTable() {
  const[api, setAPI]= React.useState([])
  const [open, setOpen] = React.useState(false);
 // const[success, setSuccess] = useState(false)
 const handleClose = () => {
  setOpen(false);
};
  const url = 'https://634f9c8578563c1d82aac06d.mockapi.io/TrialTest/'
  React.useEffect(() => {
    fetch(url)
    .then(respons => respons.json())
    .then(data => setAPI(data))
    .catch(error => console.log(error.message));
  }, [open])
  
  const handleDelete = (id)=>{
    if(confirm("Are you sure?") ==true){
      fetch(url + id, {
        method: 'Delete'
      }) 
     // .then(setSuccess(true))
      .then(setOpen(true))
      
    }
 
  }
  
  return (
    <>
<TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
        <Dialog onClose={handleClose} open={open}>
      <DialogTitle>Set backup account</DialogTitle>
      <DialogActions>
        
          <Button onClick={handleClose}>Close</Button>
        </DialogActions>
    </Dialog>
    
          <Button variant='outlined'>Create</Button>
          <TableRow>
            <TableCell>image</TableCell>
            <TableCell align="right">Name</TableCell>
            <TableCell align="right">Cost</TableCell>
            <TableCell align="right">Club</TableCell>
            <TableCell align="right">Nation</TableCell>
            <TableCell align='right'></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
        {api.map((a)=>(
          <TableRow
          key={a.id}
          sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
        >
          <TableCell component="th" scope="row">
          <Avatar alt="Remy Sharp" src={a.img} />
          </TableCell>
          <TableCell align="right">{a.name}</TableCell>
          <TableCell align="right">{a.cost}</TableCell>
          <TableCell align="right">{a.club}</TableCell>
          <TableCell align="right">{a.nation}</TableCell>
          <TableCell align='right'><Button variant='outlined' onClick={()=> handleDelete(a.id)}>Delete</Button></TableCell>
        </TableRow>
        ))}
            
         
        </TableBody>
      </Table>
    </TableContainer>
   
    </>
    
    
  );
}